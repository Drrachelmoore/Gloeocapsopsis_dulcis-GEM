def read_tsv_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    return lines


def compare_files(lines1, lines2, absolute_tolerance=1e-3, relative_tolerance=1e-3):
    for line1, line2 in zip(lines1, lines2):
        fields1 = line1.strip().split('\t')
        fields2 = line2.strip().split('\t')

        if len(fields1) != len(fields2):
            print("Files have different structures.")
            return False

        for value1, value2 in zip(fields1, fields2):
            if value1 != value2:
                try:
                    float1 = float(value1)
                    float2 = float(value2)
                    if abs(float1 - float2) <= max(absolute_tolerance, relative_tolerance * max(abs(float1), abs(float2))):
                        continue  # Values are within tolerance, consider them equal
                except ValueError:
                    pass  # Non-numeric values, continue regular comparison
                print("Files are not identical.")
                return False

    print("Files are identical within tolerances.")
    return True


file1_lines = read_tsv_file('path\\to\\reaction_deletion\\cameo\\04_reaction_deletion.tsv')
file2_lines = read_tsv_file('path\\to\\reaction_deletion\\cobrapy\\04_reaction_deletion.tsv')

are_identical = compare_files(file1_lines, file2_lines)
